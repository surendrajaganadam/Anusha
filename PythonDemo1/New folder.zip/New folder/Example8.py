print(1)
print(2)
print(3)
print(4)
print(5)
print(6)
#1o number u ave to give print stmt for 10times
# fpr sure if i want to 1000 numbers then will i give if so ???
