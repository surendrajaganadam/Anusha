class DemoClass:
    """ this is a smaple class which i am creating for understaning this class n object
    """
print(DemoClass.__doc__)

