a=["surendra",2,"ramya","sneha"]
#as of now i have defined 4 valyes which is a comp of int n string in a list

print(a)

# len(a)" total no of values present in a lust
print(len(a))

print(a[0])
print(a[1])
print(a[2])
print(a[3])
...
"to get a specific value from a list which means" \
"i want to get 2nd value from the list???" \
"every value in the list will start with 0 index" \
"0: 1st value in the list" \
"1: 2nd value in the list" \
"2: 3rd value in the list" \
"last value: n-1 which will gte last value in the list" \
"listname[index]"
...

a.append("lucky trainings")

print(a)