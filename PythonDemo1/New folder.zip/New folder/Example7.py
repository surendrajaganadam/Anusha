a=5
b=14

# i would like to wrire an if , if a>b then print "a is big to the console"

if a>b:
    print("a is big")


if a>b:
    print("a is big")
else:
    print("b is big")

if a>b:
    print("a is big")



print("test completed")