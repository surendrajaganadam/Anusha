a='this is'
b="surendra"
c=""" welcome to 
surenddra qa training program """

# print(a)
# print(b)
# print(c)
#plus  operatyor as my conc
print(a+b)
# * to print the string for those many times
print(b * 4)
#if the content present in both string is eqaul then it will return true
print(a in b)
#if the content present in both string is not eqaul then it will return true
print(a not in b)
