import math
# def function_name(function_parameters):
# 	function_body # Set of Python statements
#         return # optional return statement


def sum():
    c=3+7
    print(c)


sum()

...
"i want to creta a method in such a way that i need to pass the values for which it should perform sum operations" \
"parameter to a funciton comes into picture" \
"" \
"i want to store the outpt of the mehod into a vairbale so that moving further i can use that data in such situation  we ca" \
"use return stmt to a function"
...

def add(a,b):
    d=a+b
    print(d)

add(3,4)


def addingNumber(a,b):
    e=a+b
    return e

p1=addingNumber(2,3)
if p1>3:
    print("sum value is geatrger than 3")
