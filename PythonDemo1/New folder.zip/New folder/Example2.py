# below lines represent integer example
a=10
b=20

p="good trainer"
#below [rint is adding 2 strings hence it shouldnt throw any error messages let me run my script
print("surendra qa trainer and he is a " +p)
c=10.25
d=11.25

#we tried to add string + int , hence we got error

# print(a+b)
# print(c+d)
#below e is sum of intgeere
e=a+b
#below f is sum of floats
f=c+d
...
"whenever we represented something in doble quote it will treate it as a string " \
"so python cant add string n number directly thats whate the error message ?" \
"then how i need to print the text followed by a number??" \
"whatever the variable u want to print add str(variable) automatically that variable" \
"will be converted into a string"
"i have done in this scrpt is :"
"we created 2 intergs , 2 string "
"tater we added both of them and finally we tired to print the sum with appending a string"
"we encountered an error and we fied that issue"
...


# i want to add some message and the desired value, to do so whatever the msasage u want to print place it in double qute within the print and use + followed by ur desired value
print("integer sum is : " +str(e))
print("float sum is "  +str(f))