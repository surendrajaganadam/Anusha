a=1
while a<=10:
    print(a)
    a=a+1

#without afing anythin ht it will an infinity loop means it wont comeout from the xecution always it wl;l execute
# it will increment the value by 1 everytime and after 10times a will become 11 11<10 F iy will come out of the loop