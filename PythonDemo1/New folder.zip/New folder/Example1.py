#this is single line comment, in the next line let me try to print some name : ctrl + ?
print("Lucky Trainings")

...
"we are creating multie line comment"
...

