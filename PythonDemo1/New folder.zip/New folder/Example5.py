a=["surendra",2,"ramya","rajani"]

print(a)
#len(listname) which will get total no of ales in a list
print(len(a))

print(a.count("ramya"))